import { test, expect } from '@playwright/test';

test.describe('E2E Full Journey', () => {
  test('Complete flow: Admin creates combo -> visitor buys -> admin checks order', async ({ page }) => {
    // 1. Admin login
    await page.goto('/admin');
    await page.fill('input[type="text"]', 'admin');
    await page.fill('input[type="password"]', 'secret'); // Or whatever the local test password is
    await page.click('button:has-text("Login")');
    await expect(page.locator('text=Dashboard')).toBeVisible();

    // 2. Admin creates a new combo
    await page.click('text=Combos');
    await page.click('button:has-text("Add New Combo")');
    await page.fill('input[name="name_en"]', 'E2E Test Combo');
    await page.fill('input[name="name_bn"]', 'ই২ই টেস্ট কম্বো');
    await page.fill('input[name="price"]', '1250');
    await page.fill('input[name="market_price"]', '1500');
    // Add 1 item
    await page.click('button:has-text("Add Item")');
    await page.fill('input[placeholder="Name (EN)"]', 'Test Item 1');
    await page.fill('input[placeholder="Name (BN)"]', 'টেস্ট আইটেম ১');
    await page.fill('input[placeholder="Qty (e.g. 1 kg)"]', '1 kg');
    await page.fill('input[placeholder="Price"]', '500');
    await page.click('button:has-text("Save Combo")');
    await expect(page.locator('text=E2E Test Combo')).toBeVisible();

    // 3. Admin creates a coupon
    await page.click('text=Coupons');
    await page.click('button:has-text("Add New Coupon")');
    await page.fill('input[name="code"]', 'E2ESAVE100');
    await page.selectOption('select[name="type"]', 'fixed');
    await page.fill('input[name="value"]', '100');
    await page.fill('input[name="min_order_amount"]', '500');
    await page.click('button:has-text("Save Coupon")');
    await expect(page.locator('text=E2ESAVE100')).toBeVisible();

    // 4. Visitor opens Home
    await page.goto('/');
    await expect(page.locator('text=E2E Test Combo')).toBeVisible();

    // 5. Add to Cart
    const comboCard = page.locator('.combo-card').filter({ hasText: 'E2E Test Combo' });
    await comboCard.locator('button:has-text("Add to Cart")').click();
    
    // Check Drawer
    await expect(page.locator('text=E2E Test Combo')).toBeVisible();
    await page.click('a:has-text("Checkout")');

    // 6. Checkout
    await expect(page).toHaveURL(/.*\/checkout/);
    await page.fill('input[name="customer_name"]', 'Test User');
    await page.fill('input[name="phone"]', '01711000000');
    await page.fill('input[name="address"]', 'Test Address');
    await page.selectOption('select[name="division"]', { label: 'Dhaka' });
    // Apply coupon
    await page.fill('input[placeholder="Enter coupon code"]', 'E2ESAVE100');
    await page.click('button:has-text("Apply")');
    await expect(page.locator('text=৳100')).toBeVisible();

    // Select COD
    await page.locator('label', { hasText: 'Cash on Delivery' }).click();
    
    // Place Order
    await page.click('button:has-text("Place Order")');

    // 7. Order Confirmation
    await expect(page).toHaveURL(/.*\/order\/.+/);
    await expect(page.locator('text=Order Confirmed')).toBeVisible();
    
    // 8. Admin checks order
    await page.goto('/admin/orders');
    await expect(page.locator('text=Test User')).toBeVisible();
    await expect(page.locator('text=01711000000')).toBeVisible();
    
    // View Details
    await page.click('button:has-text("View")');
    await expect(page.locator('text=E2E Test Combo')).toBeVisible();
    
    // Mark as paid
    await page.selectOption('select', { label: 'Paid' });
    await expect(page.locator('text=Success')).toBeVisible(); // Toast or similar indicator
  });
});
